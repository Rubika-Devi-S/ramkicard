<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/includes/api-bootstrap.php';

$action = request_action();

try {
    if ($action === 'list') {
        require_permission($pdo, 'orders', 'can_view');

        $params = [];
        $where = '';

        if (in_array(
            request_value('status'),
            ['new', 'processed', 'delivered', 'cancelled'],
            true
        )) {
            $where = 'WHERE status = :status';
            $params['status'] = request_value('status');
        }

        $stmt = $pdo->prepare(
            "SELECT
                id,
                order_number,
                customer_name,
                customer_phone,
                grand_total,
                payment_status,
                status,
                DATE_FORMAT(created_at, '%d-%m-%Y %h:%i %p') AS created_at
             FROM orders
             {$where}
             ORDER BY id DESC"
        );

        $stmt->execute($params);

        json_response(true, '', $stmt->fetchAll());
    }

    if ($action === 'get') {
        require_permission($pdo, 'orders', 'can_view');

        $id = (int)request_value('id');

        $stmt = $pdo->prepare(
            "SELECT *
             FROM orders
             WHERE id = :id
             LIMIT 1"
        );

        $stmt->execute(['id' => $id]);
        $order = $stmt->fetch();

        if (!$order) {
            throw new RuntimeException('Order not found.');
        }

        $stmt = $pdo->prepare(
            "SELECT
                product_name_snapshot,
                quantity,
                final_unit_price,
                line_total
             FROM order_items
             WHERE order_id = :id
             ORDER BY id"
        );

        $stmt->execute(['id' => $id]);
        $items = $stmt->fetchAll();

        json_response(true, '', [
            'order' => $order,
            'items' => $items,
        ]);
    }

    if ($action === 'update_status') {
        require_permission($pdo, 'orders', 'can_edit');

        $id = (int)request_value('id');
        $newStatus = request_value('status');

        if (!in_array(
            $newStatus,
            ['new', 'processed', 'delivered', 'cancelled'],
            true
        )) {
            throw new RuntimeException('Invalid order status.');
        }

        $stmt = $pdo->prepare(
            "SELECT status
             FROM orders
             WHERE id = :id
             LIMIT 1"
        );

        $stmt->execute(['id' => $id]);
        $oldStatus = $stmt->fetchColumn();

        if (!$oldStatus) {
            throw new RuntimeException('Order not found.');
        }

        $notes = trim((string)request_value('notes', ''));

        $sql = "UPDATE orders
                SET status = :status,
                    admin_notes = :notes";

        if ($newStatus === 'processed') {
            $sql .= ', processed_at = NOW()';
        }

        if ($newStatus === 'delivered') {
            $sql .= ', delivered_at = NOW()';
        }

        if ($newStatus === 'cancelled') {
            $sql .= ', cancelled_at = NOW(),
                      cancellation_reason = :cancellation_reason';
        }

        $sql .= ' WHERE id = :id';

        $params = [
            'status' => $newStatus,
            'notes' => $notes ?: null,
            'id' => $id,
        ];

        if ($newStatus === 'cancelled') {
            $params['cancellation_reason'] =
                $notes ?: 'Cancelled by administrator';
        }

        $pdo->beginTransaction();

        $pdo->prepare($sql)->execute($params);

        $pdo->prepare(
            "INSERT INTO order_status_history
            (
                order_id,
                changed_by_admin_id,
                previous_status,
                new_status,
                notes
            )
            VALUES
            (
                :order_id,
                :admin_id,
                :previous_status,
                :new_status,
                :notes
            )"
        )->execute([
            'order_id' => $id,
            'admin_id' => current_admin_id(),
            'previous_status' => $oldStatus,
            'new_status' => $newStatus,
            'notes' => $notes ?: null,
        ]);

        $pdo->commit();

        activity_log(
            $pdo,
            'update_status',
            'Orders',
            'order',
            $id,
            "Order status changed from {$oldStatus} to {$newStatus}."
        );

        json_response(true, 'Order status updated successfully.');
    }

    throw new RuntimeException('Invalid action.');
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    json_response(false, $e->getMessage(), null, 422);
}
