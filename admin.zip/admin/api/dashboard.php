<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/includes/api-bootstrap.php';
require_permission($pdo, 'dashboard', 'can_view');

if (request_action() !== 'summary') {
    json_response(false, 'Invalid action.', null, 422);
}

$eventSelect = table_has_column($pdo, 'enquiries', 'event_type')
    ? 'event_type'
    : 'source AS event_type';

$counts = [
    'new_enquiries' => (int)$pdo
        ->query("SELECT COUNT(*) FROM enquiries WHERE status = 'new'")
        ->fetchColumn(),

    'new_orders' => (int)$pdo
        ->query("SELECT COUNT(*) FROM orders WHERE status = 'new'")
        ->fetchColumn(),

    'active_products' => (int)$pdo
        ->query(
            "SELECT COUNT(*)
             FROM products
             WHERE status = 'active'
               AND deleted_at IS NULL"
        )
        ->fetchColumn(),

    'customers' => (int)$pdo
        ->query("SELECT COUNT(*) FROM customers")
        ->fetchColumn(),
];

$recentEnquiries = $pdo->query(
    "SELECT
        enquiry_number,
        customer_name,
        customer_phone,
        {$eventSelect},
        status,
        DATE_FORMAT(created_at, '%d-%m-%Y %h:%i %p') AS created_at
     FROM enquiries
     ORDER BY id DESC
     LIMIT 6"
)->fetchAll();

$recentOrders = $pdo->query(
    "SELECT
        order_number,
        customer_name,
        grand_total,
        status
     FROM orders
     ORDER BY id DESC
     LIMIT 6"
)->fetchAll();

json_response(true, '', [
    'counts' => $counts,
    'recent_enquiries' => $recentEnquiries,
    'recent_orders' => $recentOrders,
]);
