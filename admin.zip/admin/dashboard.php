<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/auth.php';

if (!can_menu($pdo, 'dashboard')) {
    http_response_code(403);
    exit('Permission denied.');
}

$pageTitle = 'Dashboard';
$pageScript = 'dashboard.js';

require __DIR__ . '/includes/header.php';
?>

<div class="row g-3 mb-4">
    <div class="col-sm-6 col-xl-3">
        <div class="ramki-card stat-card">
            <div class="stat-icon"><i class="fa-solid fa-envelope-open-text"></i></div>
            <div>
                <div class="stat-label">New Enquiries</div>
                <div class="stat-value" id="statEnquiries">0</div>
            </div>
        </div>
    </div>

    <div class="col-sm-6 col-xl-3">
        <div class="ramki-card stat-card">
            <div class="stat-icon"><i class="fa-solid fa-cart-shopping"></i></div>
            <div>
                <div class="stat-label">New Orders</div>
                <div class="stat-value" id="statOrders">0</div>
            </div>
        </div>
    </div>

    <div class="col-sm-6 col-xl-3">
        <div class="ramki-card stat-card">
            <div class="stat-icon"><i class="fa-solid fa-box-open"></i></div>
            <div>
                <div class="stat-label">Active Products</div>
                <div class="stat-value" id="statProducts">0</div>
            </div>
        </div>
    </div>

    <div class="col-sm-6 col-xl-3">
        <div class="ramki-card stat-card">
            <div class="stat-icon"><i class="fa-solid fa-users"></i></div>
            <div>
                <div class="stat-label">Customers</div>
                <div class="stat-value" id="statCustomers">0</div>
            </div>
        </div>
    </div>
</div>

<div class="row g-3">
    <div class="col-xl-7">
        <div class="ramki-card p-3 h-100">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h2 class="h5 mb-0">Recent Enquiries</h2>
                <a href="enquiries.php" class="btn btn-sm btn-outline-secondary">View All</a>
            </div>

            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead>
                        <tr>
                            <th>No.</th>
                            <th>Customer</th>
                            <th>Event</th>
                            <th>Status</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody id="recentEnquiries">
                        <tr>
                            <td colspan="5" class="text-center text-muted py-4">Loading...</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="col-xl-5">
        <div class="ramki-card p-3 h-100">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h2 class="h5 mb-0">Recent Orders</h2>
                <a href="orders.php" class="btn btn-sm btn-outline-secondary">View All</a>
            </div>

            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead>
                        <tr>
                            <th>Order</th>
                            <th>Customer</th>
                            <th>Total</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody id="recentOrders">
                        <tr>
                            <td colspan="4" class="text-center text-muted py-4">Loading...</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>
