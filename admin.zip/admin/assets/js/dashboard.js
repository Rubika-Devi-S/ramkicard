function loadDashboard() {
    RamkiAdmin.request('api/dashboard.php', { action: 'summary' })
        .done(response => {
            if (!response.success) {
                RamkiAdmin.toast('error', response.message);
                return;
            }

            const data = response.data;

            $('#statEnquiries').text(data.counts.new_enquiries);
            $('#statOrders').text(data.counts.new_orders);
            $('#statProducts').text(data.counts.active_products);
            $('#statCustomers').text(data.counts.customers);

            $('#recentEnquiries').html(
                data.recent_enquiries.length
                    ? data.recent_enquiries.map(row => `
                        <tr>
                            <td>${RamkiAdmin.escape(row.enquiry_number)}</td>
                            <td>
                                <strong>${RamkiAdmin.escape(row.customer_name)}</strong><br>
                                <small>${RamkiAdmin.escape(row.customer_phone)}</small>
                            </td>
                            <td>${RamkiAdmin.escape(row.event_type || row.source || '-')}</td>
                            <td>${RamkiAdmin.statusBadge(row.status)}</td>
                            <td>${RamkiAdmin.escape(row.created_at)}</td>
                        </tr>
                    `).join('')
                    : '<tr><td colspan="5" class="text-center text-muted py-4">No enquiries found.</td></tr>'
            );

            $('#recentOrders').html(
                data.recent_orders.length
                    ? data.recent_orders.map(row => `
                        <tr>
                            <td>${RamkiAdmin.escape(row.order_number)}</td>
                            <td>${RamkiAdmin.escape(row.customer_name)}</td>
                            <td>${RamkiAdmin.money(row.grand_total)}</td>
                            <td>${RamkiAdmin.statusBadge(row.status)}</td>
                        </tr>
                    `).join('')
                    : '<tr><td colspan="4" class="text-center text-muted py-4">No orders found.</td></tr>'
            );
        })
        .fail(xhr => RamkiAdmin.error(xhr, 'Unable to load dashboard.'));
}

loadDashboard();
