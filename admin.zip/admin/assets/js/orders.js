let ordersTable;
const orderModal = bootstrap.Modal.getOrCreateInstance('#orderModal');

function loadOrders() {
    RamkiAdmin.request('api/orders.php', {
        action: 'list',
        status: $('#orderStatusFilter').val()
    })
        .done(response => {
            if (!response.success) {
                RamkiAdmin.toast('error', response.message);
                return;
            }

            if (ordersTable) {
                ordersTable.destroy();
            }

            $('#ordersTable tbody').html(
                response.data.map((row, index) => `
                    <tr>
                        <td>${index + 1}</td>
                        <td><strong>${RamkiAdmin.escape(row.order_number)}</strong></td>
                        <td>
                            ${RamkiAdmin.escape(row.customer_name)}<br>
                            <small>${RamkiAdmin.escape(row.customer_phone)}</small>
                        </td>
                        <td>${RamkiAdmin.money(row.grand_total)}</td>
                        <td>${RamkiAdmin.statusBadge(row.payment_status)}</td>
                        <td>${RamkiAdmin.statusBadge(row.status)}</td>
                        <td>${RamkiAdmin.escape(row.created_at)}</td>
                        <td>
                            <button class="btn btn-sm btn-outline-primary view-order" data-id="${row.id}">
                                <i class="fa-solid fa-eye"></i>
                            </button>
                        </td>
                    </tr>
                `).join('')
            );

            ordersTable = new DataTable('#ordersTable', {
                pageLength: 10
            });
        })
        .fail(xhr => RamkiAdmin.error(xhr));
}

$(document).on('click', '.view-order', function () {
    RamkiAdmin.request('api/orders.php', {
        action: 'get',
        id: $(this).data('id')
    })
        .done(response => {
            if (!response.success) {
                RamkiAdmin.toast('error', response.message);
                return;
            }

            const order = response.data.order;

            $('#orderForm [name="id"]').val(order.id);
            $('#orderForm [name="status"]').val(order.status);
            $('#orderForm [name="notes"]').val(order.admin_notes || '');

            const items = response.data.items.map(item => `
                <tr>
                    <td>${RamkiAdmin.escape(item.product_name_snapshot)}</td>
                    <td>${item.quantity}</td>
                    <td>${RamkiAdmin.money(item.final_unit_price)}</td>
                    <td>${RamkiAdmin.money(item.line_total)}</td>
                </tr>
            `).join('');

            $('#orderDetails').html(`
                <div class="row g-3 mb-3">
                    <div class="col-md-4">
                        <div class="p-3 bg-light rounded">
                            <small class="text-muted">Order</small>
                            <div class="fw-bold">${RamkiAdmin.escape(order.order_number)}</div>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="p-3 bg-light rounded">
                            <small class="text-muted">Customer</small>
                            <div class="fw-bold">${RamkiAdmin.escape(order.customer_name)}</div>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="p-3 bg-light rounded">
                            <small class="text-muted">Grand Total</small>
                            <div class="fw-bold">${RamkiAdmin.money(order.grand_total)}</div>
                        </div>
                    </div>
                </div>

                <div class="table-responsive">
                    <table class="table table-sm">
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>Qty</th>
                                <th>Unit Price</th>
                                <th>Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${items || '<tr><td colspan="4">No items.</td></tr>'}
                        </tbody>
                    </table>
                </div>
            `);

            orderModal.show();
        })
        .fail(xhr => RamkiAdmin.error(xhr));
});

$('#orderForm').on('submit', function (event) {
    event.preventDefault();

    RamkiAdmin.request('api/orders.php', $(this).serialize())
        .done(response => {
            if (!response.success) {
                RamkiAdmin.toast('error', response.message);
                return;
            }

            orderModal.hide();
            RamkiAdmin.toast('success', response.message);
            loadOrders();
        })
        .fail(xhr => RamkiAdmin.error(xhr));
});

$('#orderStatusFilter').on('change', loadOrders);

loadOrders();
