<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/auth.php';

if (!can_menu($pdo, 'orders')) {
    http_response_code(403);
    exit('Permission denied.');
}

$pageTitle = 'Orders';
$pageScript = 'orders.js';

require __DIR__ . '/includes/header.php';
?>

<div class="ramki-card p-3">
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-3">
        <div>
            <h2 class="h5 mb-1">Order Management</h2>
            <p class="text-muted small mb-0">
                New Orders → Processed → Delivered, with a separate Cancelled section.
            </p>
        </div>

        <select class="form-select w-auto" id="orderStatusFilter">
            <option value="">All Orders</option>
            <option value="new">New Orders</option>
            <option value="processed">Processed</option>
            <option value="delivered">Delivered</option>
            <option value="cancelled">Cancelled</option>
        </select>
    </div>

    <div class="table-responsive">
        <table class="table table-hover w-100" id="ordersTable">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Order</th>
                    <th>Customer</th>
                    <th>Total</th>
                    <th>Payment</th>
                    <th>Status</th>
                    <th>Placed</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody></tbody>
        </table>
    </div>
</div>

<div class="modal fade" id="orderModal" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <form class="modal-content" id="orderForm">
            <div class="modal-header">
                <h5 class="modal-title">Order Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body">
                <input type="hidden" name="id">
                <input type="hidden" name="action" value="update_status">

                <div id="orderDetails" class="mb-4"></div>

                <div class="row g-3">
                    <div class="col-md-5">
                        <label class="form-label">Order Status</label>
                        <select class="form-select" name="status">
                            <option value="new">New</option>
                            <option value="processed">Processed</option>
                            <option value="delivered">Delivered</option>
                            <option value="cancelled">Cancelled</option>
                        </select>
                    </div>

                    <div class="col-md-7">
                        <label class="form-label">Admin Notes / Cancellation Reason</label>
                        <textarea class="form-control" rows="3" name="notes"></textarea>
                    </div>
                </div>
            </div>

            <div class="modal-footer">
                <button class="btn btn-ramki" type="submit">Update Order</button>
            </div>
        </form>
    </div>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>
